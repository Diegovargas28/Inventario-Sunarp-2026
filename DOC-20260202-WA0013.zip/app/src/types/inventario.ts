export interface BienPatrimonial {
  id: string;
  codigo_patrimonial: string;
  responsable: string;
  usuario: string;
  descripcion: string;
  ubicac_fisica: string;
  marca: string;
  modelo: string;
  nro_serie: string;
  estado: string;
}

export type CampoBien = keyof BienPatrimonial;

export const CAMPOS_ESPERADOS: CampoBien[] = [
  'codigo_patrimonial',
  'responsable',
  'usuario',
  'descripcion',
  'ubicac_fisica',
  'marca',
  'modelo',
  'nro_serie',
  'estado'
];

export const ETIQUETAS_CAMPOS: Record<CampoBien, string> = {
  id: 'ID',
  codigo_patrimonial: 'Código Patrimonial',
  responsable: 'Responsable',
  usuario: 'Usuario',
  descripcion: 'Descripción',
  ubicac_fisica: 'Ubicación Física',
  marca: 'Marca',
  modelo: 'Modelo',
  nro_serie: 'N° Serie',
  estado: 'Estado'
};

export interface ResultadoImportacion {
  datos: BienPatrimonial[];
  camposDetectados: CampoBien[];
  camposFaltantes: CampoBien[];
  advertencias: string[];
  totalFilas: number;
}

export interface FiltrosBusqueda {
  codigoPatrimonial: string;
  ubicacionFisica: string;
  usuario: string;
  busquedaGeneral: string;
}
