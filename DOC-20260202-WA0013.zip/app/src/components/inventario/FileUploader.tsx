import { useCallback, useState } from 'react';
import { useDropzone } from 'react-dropzone';
import { Upload, FileSpreadsheet, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';

interface FileUploaderProps {
  onFileSelect: (file: File) => Promise<void> | void;
  cargando: boolean;
}

export function FileUploader({ onFileSelect, cargando }: FileUploaderProps) {
  const [error, setError] = useState<string | null>(null);

  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    setError(null);
    
    if (acceptedFiles.length === 0) {
      const mensaje = 'Por favor seleccione un archivo Excel válido (.xlsx, .xls)';
      setError(mensaje);
      toast.error(mensaje);
      return;
    }

    const archivo = acceptedFiles[0];
    
    // Validar que sea un archivo
    if (!(archivo instanceof File)) {
      const mensaje = 'El objeto seleccionado no es un archivo válido';
      setError(mensaje);
      toast.error(mensaje);
      return;
    }
    
    // Validar extensión
    const extensionesValidas = ['.xlsx', '.xls', '.xlsm'];
    const nombreOriginal = archivo.name || '';
    const ultimoPunto = nombreOriginal.lastIndexOf('.');
    const extension = ultimoPunto > 0 ? nombreOriginal.substring(ultimoPunto).toLowerCase() : '';
    
    if (!extensionesValidas.includes(extension)) {
      const mensaje = `Extensión no válida: "${extension}". Solo se permiten archivos Excel (.xlsx, .xls)`;
      setError(mensaje);
      toast.error(mensaje);
      return;
    }

    // Validar tamaño (máximo 10MB)
    const maxSize = 10 * 1024 * 1024;
    if (archivo.size === 0) {
      const mensaje = 'El archivo está vacío';
      setError(mensaje);
      toast.error(mensaje);
      return;
    }
    
    if (archivo.size > maxSize) {
      const mensaje = `El archivo es demasiado grande (${(archivo.size / 1024 / 1024).toFixed(2)}MB). Máximo 10MB`;
      setError(mensaje);
      toast.error(mensaje);
      return;
    }

    // Validar tipo MIME (pero no bloquear si no coincide, ya que algunos archivos Excel pueden tener tipos MIME diferentes)
    const tiposValidos = [
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'application/vnd.ms-excel',
      'application/octet-stream',
      'application/excel',
      'application/x-excel'
    ];
    
    if (archivo.type && !tiposValidos.includes(archivo.type)) {
      console.warn('Tipo MIME no estándar detectado:', archivo.type, '- Intentando procesar de todos modos');
    }

    console.log('Archivo seleccionado:', {
      nombre: archivo.name,
      tamaño: archivo.size,
      tipo: archivo.type,
      extension: extension
    });

    try {
      await onFileSelect(archivo);
      setError(null);
    } catch (err) {
      const mensaje = err instanceof Error ? err.message : 'Error al procesar el archivo';
      setError(mensaje);
      toast.error(mensaje);
    }
  }, [onFileSelect]);

  const { getRootProps, getInputProps, isDragActive, open, fileRejections } = useDropzone({
    onDrop,
    accept: {
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': ['.xlsx'],
      'application/vnd.ms-excel': ['.xls'],
      'application/octet-stream': ['.xlsx', '.xls']
    },
    maxFiles: 1,
    noClick: true,
    disabled: cargando,
    onDropRejected: (rejections) => {
      const rejection = rejections[0];
      if (rejection) {
        const mensaje = `Archivo rechazado: ${rejection.errors.map(e => e.message).join(', ')}`;
        setError(mensaje);
        toast.error(mensaje);
      }
    }
  });

  // Mostrar error de rechazo del dropzone
  if (fileRejections.length > 0 && !error) {
    const rejectionError = fileRejections[0].errors[0]?.message || 'Archivo no válido';
    setError(rejectionError);
  }

  return (
    <div className="space-y-4">
      <div
        {...getRootProps()}
        className={`
          border-2 border-dashed rounded-xl p-8 text-center transition-all duration-300
          ${isDragActive 
            ? 'border-blue-500 bg-blue-50' 
            : 'border-gray-300 bg-white hover:border-gray-400 hover:bg-gray-50'
          }
          ${cargando ? 'opacity-70 pointer-events-none' : ''}
          ${error ? 'border-red-300 bg-red-50' : ''}
        `}
      >
        <input {...getInputProps()} />
        
        <div className="flex flex-col items-center gap-4">
          <div className={`
            w-16 h-16 rounded-full flex items-center justify-center transition-all duration-300
            ${error ? 'bg-red-100' : isDragActive ? 'bg-blue-100' : 'bg-gray-100'}
          `}>
            {error ? (
              <AlertCircle className="w-8 h-8 text-red-500" />
            ) : isDragActive ? (
              <Upload className="w-8 h-8 text-blue-600" />
            ) : (
              <FileSpreadsheet className="w-8 h-8 text-gray-500" />
            )}
          </div>

          <div className="space-y-2">
            <p className={`text-lg font-medium ${error ? 'text-red-600' : 'text-gray-700'}`}>
              {error ? 'Error al procesar el archivo' : isDragActive ? 'Suelte el archivo aquí' : 'Arrastre su archivo Excel aquí'}
            </p>
            <p className="text-sm text-gray-500">
              {error ? 'Por favor, intente con otro archivo' : 'o haga clic en el botón para seleccionar'}
            </p>
          </div>

          <Button
            type="button"
            onClick={open}
            disabled={cargando}
            className={`
              ${error 
                ? 'bg-red-600 hover:bg-red-700' 
                : 'bg-blue-900 hover:bg-blue-800'
              } text-white
            `}
          >
            {cargando ? (
              <>
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                Procesando...
              </>
            ) : (
              <>
                <Upload className="w-4 h-4 mr-2" />
                {error ? 'Intentar con otro archivo' : 'Seleccionar Archivo'}
              </>
            )}
          </Button>

          <div className="text-center space-y-1">
            <p className="text-xs text-gray-400">
              Formatos permitidos: .xlsx, .xls (Máx. 10MB)
            </p>
            <p className="text-xs text-gray-400">
              Encabezados esperados: código patrimonial, responsable, usuario, descripción, ubicación física, marca, modelo, n° serie, estado
            </p>
          </div>
        </div>
      </div>

      {/* Mensaje de error */}
      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-medium text-red-800">Error al procesar el archivo</p>
            <p className="text-sm text-red-600 mt-1">{error}</p>
          </div>
        </div>
      )}
    </div>
  );
}
