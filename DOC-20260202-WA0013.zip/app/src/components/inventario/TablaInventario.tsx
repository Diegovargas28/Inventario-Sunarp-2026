import { useState } from 'react';
import { 
  Pencil, Save, X, Trash2, ChevronLeft, ChevronRight, 
  ChevronsLeft, ChevronsRight, AlertCircle 
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import type { BienPatrimonial, CampoBien } from '@/types/inventario';
import { ETIQUETAS_CAMPOS, CAMPOS_ESPERADOS } from '@/types/inventario';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';

interface TablaInventarioProps {
  bienes: BienPatrimonial[];
  camposDetectados?: CampoBien[];
  onActualizar: (id: string, campo: CampoBien, valor: string) => void;
  onEliminar: (id: string) => void;
}

const ITEMS_POR_PAGINA = 30;

export function TablaInventario({ 
  bienes, 
  camposDetectados = CAMPOS_ESPERADOS, 
  onActualizar, 
  onEliminar 
}: TablaInventarioProps) {
  const [paginaActual, setPaginaActual] = useState(1);
  const [editando, setEditando] = useState<string | null>(null);
  const [valoresEdicion, setValoresEdicion] = useState<Partial<BienPatrimonial>>({});

  const totalPaginas = Math.ceil(bienes.length / ITEMS_POR_PAGINA);
  const inicio = (paginaActual - 1) * ITEMS_POR_PAGINA;
  const fin = inicio + ITEMS_POR_PAGINA;
  const bienesPagina = bienes.slice(inicio, fin);

  const iniciarEdicion = (bien: BienPatrimonial) => {
    setEditando(bien.id);
    setValoresEdicion({ ...bien });
  };

  const cancelarEdicion = () => {
    setEditando(null);
    setValoresEdicion({});
  };

  const guardarEdicion = (id: string) => {
    camposDetectados.forEach(campo => {
      if (valoresEdicion[campo] !== undefined) {
        onActualizar(id, campo, valoresEdicion[campo] || '');
      }
    });
    setEditando(null);
    setValoresEdicion({});
  };

  const actualizarValorEdicion = (campo: CampoBien, valor: string) => {
    setValoresEdicion(prev => ({ ...prev, [campo]: valor }));
  };

  const irAPagina = (pagina: number) => {
    if (pagina >= 1 && pagina <= totalPaginas) {
      setPaginaActual(pagina);
    }
  };

  const getEstadoColor = (estado: string) => {
    const estadoLower = estado.toLowerCase();
    if (estadoLower.includes('bueno') || estadoLower.includes('operativo')) {
      return 'bg-green-100 text-green-800 border-green-200';
    }
    if (estadoLower.includes('regular') || estadoLower.includes('mantenimiento')) {
      return 'bg-yellow-100 text-yellow-800 border-yellow-200';
    }
    if (estadoLower.includes('malo') || estadoLower.includes('dañado') || estadoLower.includes('baja')) {
      return 'bg-red-100 text-red-800 border-red-200';
    }
    return 'bg-gray-100 text-gray-800 border-gray-200';
  };

  // Calcular rango de páginas a mostrar
  const getPaginasVisibles = () => {
    const maxPaginasVisibles = 5;
    let inicioRango = Math.max(1, paginaActual - Math.floor(maxPaginasVisibles / 2));
    let finRango = Math.min(totalPaginas, inicioRango + maxPaginasVisibles - 1);
    
    if (finRango - inicioRango + 1 < maxPaginasVisibles) {
      inicioRango = Math.max(1, finRango - maxPaginasVisibles + 1);
    }
    
    return Array.from({ length: finRango - inicioRango + 1 }, (_, i) => inicioRango + i);
  };

  if (bienes.length === 0) {
    return (
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-12 text-center">
        <AlertCircle className="w-12 h-12 text-gray-300 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-gray-600 mb-2">
          No hay registros para mostrar
        </h3>
        <p className="text-sm text-gray-500">
          Importe un archivo Excel para comenzar
        </p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
      {/* Tabla */}
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow className="bg-gray-50 hover:bg-gray-50">
              <TableHead className="w-14 text-center font-semibold text-gray-700">N°</TableHead>
              {camposDetectados.map(campo => (
                <TableHead key={campo} className="font-semibold text-gray-700 whitespace-nowrap">
                  {ETIQUETAS_CAMPOS[campo]}
                </TableHead>
              ))}
              <TableHead className="w-24 text-center font-semibold text-gray-700">Acciones</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {bienesPagina.map((bien, index) => {
              const numeroFila = inicio + index + 1;
              const estaEditando = editando === bien.id;

              return (
                <TableRow 
                  key={bien.id} 
                  className={`
                    ${estaEditando ? 'bg-blue-50' : 'hover:bg-gray-50'}
                    transition-colors duration-150
                  `}
                >
                  <TableCell className="text-center text-gray-500 font-medium">
                    {numeroFila}
                  </TableCell>
                  
                  {camposDetectados.map(campo => (
                    <TableCell key={campo} className="py-2">
                      {estaEditando ? (
                        campo === 'estado' ? (
                          <Select
                            value={valoresEdicion[campo] || ''}
                            onValueChange={(valor) => actualizarValorEdicion(campo, valor)}
                          >
                            <SelectTrigger className="w-full h-8 text-sm">
                              <SelectValue placeholder="Seleccione..." />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="BUENO">BUENO</SelectItem>
                              <SelectItem value="REGULAR">REGULAR</SelectItem>
                              <SelectItem value="MALO">MALO</SelectItem>
                              <SelectItem value="OPERATIVO">OPERATIVO</SelectItem>
                              <SelectItem value="INOPERATIVO">INOPERATIVO</SelectItem>
                              <SelectItem value="EN MANTENIMIENTO">EN MANTENIMIENTO</SelectItem>
                              <SelectItem value="BAJA">BAJA</SelectItem>
                            </SelectContent>
                          </Select>
                        ) : (
                          <Input
                            type="text"
                            value={valoresEdicion[campo] || ''}
                            onChange={(e) => actualizarValorEdicion(campo, e.target.value)}
                            className="w-full h-8 text-sm px-2"
                          />
                        )
                      ) : (
                        <span className={`
                          text-sm 
                          ${campo === 'estado' ? '' : 'text-gray-700'}
                        `}>
                          {campo === 'estado' && bien[campo] ? (
                            <Badge variant="outline" className={getEstadoColor(bien[campo])}>
                              {bien[campo]}
                            </Badge>
                          ) : (
                            bien[campo] || '-'
                          )}
                        </span>
                      )}
                    </TableCell>
                  ))}

                  <TableCell className="text-center py-2">
                    {estaEditando ? (
                      <div className="flex items-center justify-center gap-1">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => guardarEdicion(bien.id)}
                          className="h-8 w-8 text-green-600 hover:text-green-700 hover:bg-green-50"
                        >
                          <Save className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={cancelarEdicion}
                          className="h-8 w-8 text-red-600 hover:text-red-700 hover:bg-red-50"
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      </div>
                    ) : (
                      <div className="flex items-center justify-center gap-1">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => iniciarEdicion(bien)}
                          className="h-8 w-8 text-blue-600 hover:text-blue-700 hover:bg-blue-50"
                        >
                          <Pencil className="w-4 h-4" />
                        </Button>
                        
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8 text-red-600 hover:text-red-700 hover:bg-red-50"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle className="flex items-center gap-2">
                                <AlertCircle className="w-5 h-5 text-red-500" />
                                Confirmar eliminación
                              </AlertDialogTitle>
                              <AlertDialogDescription>
                                ¿Está seguro de eliminar este registro? 
                                <br />
                                <span className="font-medium text-gray-700">
                                  Código: {bien.codigo_patrimonial || 'N/A'}
                                </span>
                                <br />
                                Esta acción no se puede deshacer.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancelar</AlertDialogCancel>
                              <AlertDialogAction 
                                onClick={() => onEliminar(bien.id)}
                                className="bg-red-600 hover:bg-red-700"
                              >
                                Eliminar
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    )}
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </div>

      {/* Paginación */}
      {totalPaginas > 1 && (
        <div className="border-t border-gray-200 bg-gray-50 px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="text-sm text-gray-600">
              Mostrando <span className="font-medium">{inicio + 1}</span> -{' '}
              <span className="font-medium">{Math.min(fin, bienes.length)}</span> de{' '}
              <span className="font-medium">{bienes.length}</span> registros
            </div>

            <div className="flex items-center gap-1">
              <Button
                variant="outline"
                size="icon"
                onClick={() => irAPagina(1)}
                disabled={paginaActual === 1}
                className="h-8 w-8"
              >
                <ChevronsLeft className="w-4 h-4" />
              </Button>
              <Button
                variant="outline"
                size="icon"
                onClick={() => irAPagina(paginaActual - 1)}
                disabled={paginaActual === 1}
                className="h-8 w-8"
              >
                <ChevronLeft className="w-4 h-4" />
              </Button>

              {getPaginasVisibles().map(pagina => (
                <Button
                  key={pagina}
                  variant={pagina === paginaActual ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => irAPagina(pagina)}
                  className={`h-8 min-w-8 px-3 ${
                    pagina === paginaActual 
                      ? 'bg-blue-900 hover:bg-blue-800 text-white' 
                      : ''
                  }`}
                >
                  {pagina}
                </Button>
              ))}

              <Button
                variant="outline"
                size="icon"
                onClick={() => irAPagina(paginaActual + 1)}
                disabled={paginaActual === totalPaginas}
                className="h-8 w-8"
              >
                <ChevronRight className="w-4 h-4" />
              </Button>
              <Button
                variant="outline"
                size="icon"
                onClick={() => irAPagina(totalPaginas)}
                disabled={paginaActual === totalPaginas}
                className="h-8 w-8"
              >
                <ChevronsRight className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
