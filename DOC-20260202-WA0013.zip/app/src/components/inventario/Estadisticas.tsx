import { Package, Users, MapPin, CheckCircle } from 'lucide-react';
import type { BienPatrimonial } from '@/types/inventario';

interface EstadisticasProps {
  bienes: BienPatrimonial[];
}

export function Estadisticas({ bienes }: EstadisticasProps) {
  const totalBienes = bienes.length;
  
  const usuariosUnicos = new Set(bienes.map(b => b.usuario).filter(Boolean)).size;
  
  const ubicacionesUnicas = new Set(bienes.map(b => b.ubicac_fisica).filter(Boolean)).size;
  
  const bienesOperativos = bienes.filter(b => {
    const estado = b.estado?.toLowerCase() || '';
    return estado.includes('bueno') || estado.includes('operativo');
  }).length;

  const estadisticas = [
    {
      titulo: 'Total Bienes',
      valor: totalBienes,
      icono: Package,
      color: 'bg-blue-500',
      lightColor: 'bg-blue-50',
      textColor: 'text-blue-600'
    },
    {
      titulo: 'Usuarios',
      valor: usuariosUnicos,
      icono: Users,
      color: 'bg-green-500',
      lightColor: 'bg-green-50',
      textColor: 'text-green-600'
    },
    {
      titulo: 'Ubicaciones',
      valor: ubicacionesUnicas,
      icono: MapPin,
      color: 'bg-purple-500',
      lightColor: 'bg-purple-50',
      textColor: 'text-purple-600'
    },
    {
      titulo: 'Bienes Operativos',
      valor: bienesOperativos,
      icono: CheckCircle,
      color: 'bg-emerald-500',
      lightColor: 'bg-emerald-50',
      textColor: 'text-emerald-600'
    }
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {estadisticas.map((stat, index) => (
        <div 
          key={index}
          className="bg-white rounded-xl shadow-sm border border-gray-200 p-5 hover:shadow-md transition-shadow duration-200"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500 font-medium mb-1">{stat.titulo}</p>
              <p className={`text-3xl font-bold ${stat.textColor}`}>
                {stat.valor.toLocaleString()}
              </p>
            </div>
            <div className={`${stat.lightColor} rounded-xl p-3`}>
              <stat.icono className={`w-6 h-6 ${stat.textColor}`} />
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
