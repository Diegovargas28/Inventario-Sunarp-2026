export function WaterMark() {
  return (
    <div className="fixed bottom-4 right-4 z-50 pointer-events-none">
      <div className="bg-white/90 backdrop-blur-sm border border-gray-200 rounded-lg px-4 py-2 shadow-lg">
        <p className="text-xs font-medium text-gray-500">
          Designed by <span className="text-blue-600 font-semibold">Diegovc</span>
        </p>
      </div>
    </div>
  );
}
