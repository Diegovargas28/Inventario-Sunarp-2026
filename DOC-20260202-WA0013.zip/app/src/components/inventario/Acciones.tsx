import { Download, Trash2, FileSpreadsheet, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';

interface AccionesProps {
  onExportar: () => void;
  onLimpiar: () => void;
  hayDatos: boolean;
  totalRegistros: number;
}

export function Acciones({ onExportar, onLimpiar, hayDatos, totalRegistros }: AccionesProps) {
  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-5">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="bg-blue-50 rounded-xl p-3">
            <FileSpreadsheet className="w-6 h-6 text-blue-600" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-gray-800">Gestión de Datos</h3>
            <p className="text-sm text-gray-500">
              {hayDatos 
                ? `${totalRegistros} registro${totalRegistros !== 1 ? 's' : ''} cargado${totalRegistros !== 1 ? 's' : ''}` 
                : 'No hay datos cargados'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <Button
            onClick={onExportar}
            disabled={!hayDatos}
            className="bg-green-600 hover:bg-green-700 text-white disabled:opacity-50"
          >
            <Download className="w-4 h-4 mr-2" />
            Exportar Excel
          </Button>

          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button
                variant="outline"
                disabled={!hayDatos}
                className="text-red-600 border-red-200 hover:bg-red-50 disabled:opacity-50"
              >
                <Trash2 className="w-4 h-4 mr-2" />
                Limpiar
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle className="flex items-center gap-2">
                  <RefreshCw className="w-5 h-5 text-orange-500" />
                  ¿Limpiar todos los datos?
                </AlertDialogTitle>
                <AlertDialogDescription>
                  Esta acción eliminará todos los registros del inventario 
                  incluyendo los guardados en el almacenamiento local.
                  <br /><br />
                  <span className="font-medium text-gray-700">
                    Total de registros a eliminar: {totalRegistros}
                  </span>
                  <br />
                  Esta acción no se puede deshacer.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancelar</AlertDialogCancel>
                <AlertDialogAction 
                  onClick={onLimpiar}
                  className="bg-red-600 hover:bg-red-700"
                >
                  Sí, limpiar todo
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      </div>
    </div>
  );
}
