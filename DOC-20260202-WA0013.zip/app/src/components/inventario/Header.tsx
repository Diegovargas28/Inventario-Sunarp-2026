import { Building2, Calendar, Database } from 'lucide-react';

export function Header() {
  return (
    <header className="bg-gradient-to-r from-blue-900 via-blue-800 to-blue-900 text-white shadow-lg">
      <div className="container mx-auto px-4 py-5">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          {/* Logo y título */}
          <div className="flex items-center gap-4">
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-3">
              <Building2 className="w-10 h-10 text-white" />
            </div>
            <div>
              <h1 className="text-2xl md:text-3xl font-bold tracking-tight">
                SUNARP
              </h1>
              <p className="text-blue-200 text-sm font-medium">
                Superintendencia Nacional de los Registros Públicos
              </p>
            </div>
          </div>

          {/* Información del sistema */}
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2 bg-white/10 backdrop-blur-sm rounded-lg px-4 py-2">
              <Database className="w-5 h-5 text-blue-200" />
              <div>
                <p className="text-xs text-blue-200">Sistema</p>
                <p className="text-sm font-semibold">Inventario Institucional</p>
              </div>
            </div>
            
            <div className="flex items-center gap-2 bg-white/10 backdrop-blur-sm rounded-lg px-4 py-2">
              <Calendar className="w-5 h-5 text-blue-200" />
              <div>
                <p className="text-xs text-blue-200">Año</p>
                <p className="text-sm font-semibold">2026</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
