import { Search, X, MapPin, User, Hash } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import type { FiltrosBusqueda as FiltrosType } from '@/types/inventario';

interface FiltrosBusquedaProps {
  filtros: FiltrosType;
  onFiltroChange: (campo: keyof FiltrosType, valor: string) => void;
  onLimpiarFiltros: () => void;
  totalResultados: number;
}

export function FiltrosBusquedaComponent({ 
  filtros, 
  onFiltroChange, 
  onLimpiarFiltros,
  totalResultados 
}: FiltrosBusquedaProps) {
  const hayFiltrosActivos = 
    filtros.codigoPatrimonial || 
    filtros.ubicacionFisica || 
    filtros.usuario || 
    filtros.busquedaGeneral;

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-5">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-gray-800 flex items-center gap-2">
          <Search className="w-5 h-5 text-blue-900" />
          Filtros de Búsqueda
        </h3>
        <div className="flex items-center gap-3">
          <span className="text-sm text-gray-500">
            {totalResultados} resultado{totalResultados !== 1 ? 's' : ''}
          </span>
          {hayFiltrosActivos && (
            <Button
              variant="outline"
              size="sm"
              onClick={onLimpiarFiltros}
              className="text-red-600 border-red-200 hover:bg-red-50"
            >
              <X className="w-4 h-4 mr-1" />
              Limpiar
            </Button>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Búsqueda por código patrimonial */}
        <div className="relative">
          <label className="block text-xs font-medium text-gray-600 mb-1.5">
            Código Patrimonial
          </label>
          <div className="relative">
            <Hash className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <Input
              type="text"
              placeholder="Buscar código..."
              value={filtros.codigoPatrimonial}
              onChange={(e) => onFiltroChange('codigoPatrimonial', e.target.value)}
              className="pl-9 h-10"
            />
          </div>
        </div>

        {/* Búsqueda por ubicación física */}
        <div className="relative">
          <label className="block text-xs font-medium text-gray-600 mb-1.5">
            Ubicación Física
          </label>
          <div className="relative">
            <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <Input
              type="text"
              placeholder="Buscar ubicación..."
              value={filtros.ubicacionFisica}
              onChange={(e) => onFiltroChange('ubicacionFisica', e.target.value)}
              className="pl-9 h-10"
            />
          </div>
        </div>

        {/* Búsqueda por usuario */}
        <div className="relative">
          <label className="block text-xs font-medium text-gray-600 mb-1.5">
            Usuario
          </label>
          <div className="relative">
            <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <Input
              type="text"
              placeholder="Buscar usuario..."
              value={filtros.usuario}
              onChange={(e) => onFiltroChange('usuario', e.target.value)}
              className="pl-9 h-10"
            />
          </div>
        </div>

        {/* Búsqueda general */}
        <div className="relative">
          <label className="block text-xs font-medium text-gray-600 mb-1.5">
            Búsqueda General
          </label>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <Input
              type="text"
              placeholder="Buscar en todos los campos..."
              value={filtros.busquedaGeneral}
              onChange={(e) => onFiltroChange('busquedaGeneral', e.target.value)}
              className="pl-9 h-10"
            />
          </div>
        </div>
      </div>
    </div>
  );
}
