import { useState, useEffect, useCallback } from 'react';
import type { BienPatrimonial, FiltrosBusqueda, CampoBien } from '@/types/inventario';
import { CAMPOS_ESPERADOS } from '@/types/inventario';
import { importarExcel, exportarExcel } from '@/utils/excelUtils';
import { toast } from 'sonner';

const STORAGE_KEY = 'sunarp_inventario_2026';

interface StoredData {
  bienes: BienPatrimonial[];
  camposDetectados: CampoBien[];
  ultimaActualizacion: string;
}

export function useInventario() {
  const [bienes, setBienes] = useState<BienPatrimonial[]>([]);
  const [bienesFiltrados, setBienesFiltrados] = useState<BienPatrimonial[]>([]);
  const [cargando, setCargando] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [filtros, setFiltros] = useState<FiltrosBusqueda>({
    codigoPatrimonial: '',
    ubicacionFisica: '',
    usuario: '',
    busquedaGeneral: ''
  });
  const [camposDetectados, setCamposDetectados] = useState<CampoBien[]>([]);
  const [hayDatos, setHayDatos] = useState(false);
  const [inicializado, setInicializado] = useState(false);

  // Cargar datos del localStorage al iniciar
  useEffect(() => {
    const cargarDatosGuardados = () => {
      try {
        const datosGuardados = localStorage.getItem(STORAGE_KEY);
        if (datosGuardados) {
          const parsed: StoredData = JSON.parse(datosGuardados);
          
          if (parsed.bienes && Array.isArray(parsed.bienes) && parsed.bienes.length > 0) {
            console.log('Cargando datos del localStorage:', parsed.bienes.length, 'registros');
            setBienes(parsed.bienes);
            setBienesFiltrados(parsed.bienes);
            setCamposDetectados(parsed.camposDetectados?.length > 0 ? parsed.camposDetectados : CAMPOS_ESPERADOS);
            setHayDatos(true);
            toast.success(`Datos recuperados: ${parsed.bienes.length} registros`);
          } else {
            console.log('No hay datos válidos en localStorage');
            setHayDatos(false);
          }
        }
      } catch (error) {
        console.error('Error al cargar datos del localStorage:', error);
        toast.error('Error al cargar datos guardados');
        // Limpiar localStorage corrupto
        localStorage.removeItem(STORAGE_KEY);
      } finally {
        setInicializado(true);
      }
    };

    cargarDatosGuardados();
  }, []);

  // Guardar datos en localStorage cuando cambien
  useEffect(() => {
    if (!inicializado) return;
    
    try {
      if (bienes.length > 0) {
        const datosAGuardar: StoredData = {
          bienes,
          camposDetectados: camposDetectados.length > 0 ? camposDetectados : CAMPOS_ESPERADOS,
          ultimaActualizacion: new Date().toISOString()
        };
        localStorage.setItem(STORAGE_KEY, JSON.stringify(datosAGuardar));
        console.log('Datos guardados en localStorage:', bienes.length, 'registros');
      } else {
        localStorage.removeItem(STORAGE_KEY);
      }
    } catch (error) {
      console.error('Error al guardar en localStorage:', error);
      toast.error('Error al guardar datos localmente');
    }
  }, [bienes, camposDetectados, inicializado]);

  // Aplicar filtros
  useEffect(() => {
    if (!inicializado) return;
    
    let resultado = [...bienes];

    if (filtros.codigoPatrimonial?.trim()) {
      const termino = filtros.codigoPatrimonial.toLowerCase().trim();
      resultado = resultado.filter(b => 
        b.codigo_patrimonial?.toLowerCase().includes(termino)
      );
    }

    if (filtros.ubicacionFisica?.trim()) {
      const termino = filtros.ubicacionFisica.toLowerCase().trim();
      resultado = resultado.filter(b => 
        b.ubicac_fisica?.toLowerCase().includes(termino)
      );
    }

    if (filtros.usuario?.trim()) {
      const termino = filtros.usuario.toLowerCase().trim();
      resultado = resultado.filter(b => 
        b.usuario?.toLowerCase().includes(termino)
      );
    }

    if (filtros.busquedaGeneral?.trim()) {
      const termino = filtros.busquedaGeneral.toLowerCase().trim();
      resultado = resultado.filter(b => 
        Object.entries(b).some(([key, valor]) => {
          if (key === 'id') return false;
          return valor?.toString().toLowerCase().includes(termino);
        })
      );
    }

    setBienesFiltrados(resultado);
  }, [bienes, filtros, inicializado]);

  const importarArchivo = useCallback(async (archivo: File) => {
    setCargando(true);
    setError(null);
    
    try {
      console.log('Iniciando importación de archivo:', archivo.name);
      
      const resultado = await importarExcel(archivo);
      
      console.log('Resultado de importación:', {
        totalRegistros: resultado.datos.length,
        camposDetectados: resultado.camposDetectados,
        advertencias: resultado.advertencias
      });
      
      if (resultado.datos.length === 0) {
        const mensaje = 'No se encontraron datos válidos en el archivo';
        setError(mensaje);
        toast.error(mensaje);
        return;
      }

      // Actualizar estados de forma síncrona para evitar inconsistencias
      setBienes(resultado.datos);
      setBienesFiltrados(resultado.datos);
      setCamposDetectados(resultado.camposDetectados.length > 0 ? resultado.camposDetectados : CAMPOS_ESPERADOS);
      setHayDatos(true);
      
      // Limpiar filtros al importar nuevos datos
      setFiltros({
        codigoPatrimonial: '',
        ubicacionFisica: '',
        usuario: '',
        busquedaGeneral: ''
      });

      // Mostrar advertencias si hay campos faltantes
      if (resultado.advertencias.length > 0) {
        resultado.advertencias.forEach(adv => {
          console.warn('Advertencia de importación:', adv);
          toast.warning(adv);
        });
      }

      toast.success(`Se importaron ${resultado.datos.length} registros correctamente`);
    } catch (err) {
      const mensaje = err instanceof Error ? err.message : 'Error desconocido al importar el archivo';
      console.error('Error en importarArchivo:', err);
      setError(mensaje);
      toast.error(`Error al importar: ${mensaje}`);
      throw err; // Re-lanzar para que el componente pueda manejarlo
    } finally {
      setCargando(false);
    }
  }, []);

  const exportarArchivo = useCallback(() => {
    if (bienes.length === 0) {
      toast.error('No hay datos para exportar');
      return;
    }

    try {
      const camposAExportar = camposDetectados.length > 0 ? camposDetectados : CAMPOS_ESPERADOS;
      exportarExcel(bienes, camposAExportar);
      toast.success('Archivo exportado correctamente');
    } catch (err) {
      const mensaje = err instanceof Error ? err.message : 'Error desconocido';
      console.error('Error en exportarArchivo:', err);
      toast.error(`Error al exportar: ${mensaje}`);
    }
  }, [bienes, camposDetectados]);

  const actualizarBien = useCallback((id: string, campo: CampoBien, valor: string) => {
    setBienes(prev => {
      const nuevosBienes = prev.map(bien => 
        bien.id === id ? { ...bien, [campo]: valor } : bien
      );
      return nuevosBienes;
    });
    toast.success('Registro actualizado');
  }, []);

  const eliminarBien = useCallback((id: string) => {
    setBienes(prev => {
      const nuevosBienes = prev.filter(b => b.id !== id);
      if (nuevosBienes.length === 0) {
        setHayDatos(false);
      }
      return nuevosBienes;
    });
    toast.success('Registro eliminado');
  }, []);

  const limpiarDatos = useCallback(() => {
    setBienes([]);
    setBienesFiltrados([]);
    setCamposDetectados([]);
    setHayDatos(false);
    setError(null);
    setFiltros({
      codigoPatrimonial: '',
      ubicacionFisica: '',
      usuario: '',
      busquedaGeneral: ''
    });
    localStorage.removeItem(STORAGE_KEY);
    toast.success('Datos limpiados correctamente');
  }, []);

  const actualizarFiltro = useCallback((campo: keyof FiltrosBusqueda, valor: string) => {
    setFiltros(prev => ({ ...prev, [campo]: valor }));
  }, []);

  const limpiarFiltros = useCallback(() => {
    setFiltros({
      codigoPatrimonial: '',
      ubicacionFisica: '',
      usuario: '',
      busquedaGeneral: ''
    });
  }, []);

  return {
    bienes,
    bienesFiltrados,
    cargando,
    error,
    filtros,
    camposDetectados,
    hayDatos,
    inicializado,
    importarArchivo,
    exportarArchivo,
    actualizarBien,
    eliminarBien,
    limpiarDatos,
    actualizarFiltro,
    limpiarFiltros
  };
}
