import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import type { BienPatrimonial, ResultadoImportacion, CampoBien } from '@/types/inventario';
import { CAMPOS_ESPERADOS } from '@/types/inventario';

// Función para normalizar nombres de columnas
function normalizarColumna(nombre: string): string {
  if (!nombre) return '';
  return nombre
    .toString()
    .toLowerCase()
    .trim()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '') // Eliminar acentos
    .replace(/[°º]/g, 'o')           // Reemplazar símbolos de ordinal
    .replace(/[\s\.\-]+/g, '_')     // Espacios, puntos y guiones a guiones bajos
    .replace(/^_+|_+$/g, '')         // Eliminar guiones bajos al inicio y final
    .replace(/_+/g, '_');            // Colapsar múltiples guiones bajos
}

// Función para extraer palabras clave de un encabezado
function extraerPalabrasClave(texto: string): string[] {
  const normalizado = normalizarColumna(texto);
  return normalizado.split('_').filter(p => p.length > 0);
}

// Función para calcular similitud entre dos textos (0 a 1)
function calcularSimilitud(texto1: string, texto2: string): number {
  const palabras1 = extraerPalabrasClave(texto1);
  const palabras2 = extraerPalabrasClave(texto2);
  
  if (palabras1.length === 0 || palabras2.length === 0) return 0;
  
  // Contar palabras coincidentes
  let coincidencias = 0;
  for (const p1 of palabras1) {
    for (const p2 of palabras2) {
      if (p1 === p2 || p1.includes(p2) || p2.includes(p1)) {
        coincidencias++;
      }
    }
  }
  
  return coincidencias / Math.max(palabras1.length, palabras2.length);
}

// Mapeo de posibles variaciones de nombres de columnas
const MAPEO_COLUMNAS: Record<string, string[]> = {
  'codigo_patrimonial': [
    'codigo_patrimonial', 'codigopatrimonial', 'codigo', 'cod_patrimonial', 
    'codpatrimonial', 'cod_pat', 'codpat', 'patrimonial', 'codigo_pat', 
    'cod_patrimonio', 'codpatrimonio', 'nro_patrimonial', 'nropatrimonial',
    'numero_patrimonial', 'numeropatrimonial', 'num_patrimonial', 'n_patrimonial',
    'patrimonio', 'cod_bien', 'codbien', 'codigo_bien', 'codigobien',
    'bien_patrimonial', 'bienpatrimonial', 'id_patrimonial', 'idpatrimonial'
  ],
  'responsable': [
    'responsable', 'resp', 'responsable_area', 'responsablearea', 'resp_area',
    'resparea', 'area_responsable', 'arearesponsable', 'encargado', 'encargado_area',
    'jefe', 'jefe_area', 'supervisor', 'coordinador', 'administrador'
  ],
  'usuario': [
    'usuario', 'user', 'usua', 'asignado', 'asignado_a', 'asignadoa', 'asignacion',
    'usuario_asignado', 'usuarioasignado', 'user_asignado', 'usser', 'usuaario',
    'empleado', 'trabajador', 'personal', 'funcionario', 'operario',
    'nombre_usuario', 'nombreusuario', 'nombre_user', 'nombreuser'
  ],
  'descripcion': [
    'descripcion', 'desc', 'descrip', 'nombre', 'detalle', 'bien', 
    'bien_patrimonial', 'bienpatrimonial', 'descripcion_bien', 'descripcionbien',
    'desc_bien', 'descbien', 'nombre_bien', 'nombrebien', 'denominacion',
    'denominacion_bien', 'tipo_bien', 'tipobien', 'clase_bien', 'clasebien',
    'articulo', 'producto', 'item', 'item_descripcion', 'itemdescripcion'
  ],
  'ubicac_fisica': [
    'ubicac_fisica', 'ubicacfisica', 'ubicacion', 'ubicacion_fisica', 
    'ubicacionfisica', 'local', 'area', 'oficina', 'dependencia', 
    'ubica_fisica', 'ubicafisica', 'ub_fisica', 'ubfisica', 'ubica',
    'lugar', 'sede', 'ambiente', 'espacio', 'sector', 'zona',
    'ubicacion_actual', 'ubicacionactual', 'ubic_actual', 'ubicactual',
    'direccion', 'direccion_fisica', 'direccionfisica', 'dir_fisica',
    'piso', 'piso_oficina', 'nivel', 'torre', 'ala', 'modulo'
  ],
  'marca': [
    'marca', 'fabricante', 'brand', 'make', 'marca_bien', 'marcabien',
    'marca_producto', 'marcaproducto', 'fabricacion', 'constructor',
    'empresa_fabricante', 'empresafabricante', 'marca_fab', 'marcafab'
  ],
  'modelo': [
    'modelo', 'model', 'mod', 'modelo_bien', 'modelobien', 'modelo_producto',
    'modeloproducto', 'tipo_modelo', 'tipomodelo', 'mod_bien', 'modbien',
    'modelo_equipo', 'modeloequipo', 'version', 'version_modelo', 'model_version',
    'linea', 'linea_modelo', 'lineamodelo', 'serie_modelo', 'seriemodelo',
    'referencia', 'ref', 'referencia_modelo', 'referenciamodelo', 'codigo_modelo',
    'codigomodelo', 'cod_modelo', 'codmodelo'
  ],
  'nro_serie': [
    'nro_serie', 'nroserie', 'numero_serie', 'numeroserie', 'serie', 'serial', 
    'n_serie', 'nserie', 'ns', 'nro_ser', 'nroser', 'num_serie', 'numserie',
    'numero_ser', 'numeroser', 'no_serie', 'noserie', 'serie_bien', 'seriebien',
    'serie_producto', 'serieproducto', 'serie_equipo', 'serieequipo',
    'codigo_serie', 'codigoserie', 'cod_serie', 'codserie', 'codigo_serial',
    'serieno', 'serie_no', 'serie_numero', 'serienumero', 'serie_nro', 'serienro',
    'nro_de_serie', 'nrodeserie', 'numero_de_serie', 'numerodeserie',
    'identificacion_serie', 'identificacionserie', 'id_serie', 'idserie',
    'part_number', 'partnumber', 'pn', 'p_n', 'numero_parte', 'numeroparte'
  ],
  'estado': [
    'estado', 'status', 'condicion', 'situacion', 'situación', 'estado_bien',
    'estadobien', 'estado_actual', 'estadoactual', 'est_actual', 'estactual',
    'condicion_bien', 'condicionbien', 'situacion_bien', 'situacionbien',
    'estado_conservacion', 'estadoconservacion', 'conservacion', 'operatividad',
    'funcionamiento', 'estado_funcional', 'estadofuncional', 'estado_operativo',
    'estadooperativo', 'estado_fisico', 'estadofisico'
  ]
};

// Función para detectar el tipo de columna basado en el encabezado
function detectarTipoColumna(encabezado: string): { campo: string | null; confianza: number } {
  const encabezadoNormalizado = normalizarColumna(encabezado);
  
  if (!encabezadoNormalizado) {
    return { campo: null, confianza: 0 };
  }
  
  let mejorCoincidencia: { campo: string | null; confianza: number } = { campo: null, confianza: 0 };
  
  // Primera pasada: coincidencia exacta o contiene
  for (const [campoEstandar, posiblesNombres] of Object.entries(MAPEO_COLUMNAS)) {
    for (const nombre of posiblesNombres) {
      // Coincidencia exacta
      if (encabezadoNormalizado === nombre) {
        return { campo: campoEstandar, confianza: 1 };
      }
      
      // El encabezado contiene el nombre o viceversa
      if (encabezadoNormalizado.includes(nombre) || nombre.includes(encabezadoNormalizado)) {
        const confianza = Math.max(
          nombre.length / encabezadoNormalizado.length,
          encabezadoNormalizado.length / nombre.length
        ) * 0.9;
        
        if (confianza > mejorCoincidencia.confianza) {
          mejorCoincidencia = { campo: campoEstandar, confianza };
        }
      }
    }
  }
  
  // Segunda pasada: similitud de palabras clave
  if (mejorCoincidencia.confianza < 0.5) {
    for (const [campoEstandar, posiblesNombres] of Object.entries(MAPEO_COLUMNAS)) {
      for (const nombre of posiblesNombres) {
        const similitud = calcularSimilitud(encabezadoNormalizado, nombre);
        if (similitud > mejorCoincidencia.confianza && similitud >= 0.5) {
          mejorCoincidencia = { campo: campoEstandar, confianza: similitud };
        }
      }
    }
  }
  
  // Tercera pasada: detección especial para casos específicos
  if (mejorCoincidencia.confianza < 0.5) {
    const palabras = extraerPalabrasClave(encabezadoNormalizado);
    
    // Detectar modelo
    if (palabras.some(p => p === 'modelo' || p === 'model' || p === 'mod')) {
      return { campo: 'modelo', confianza: 0.8 };
    }
    
    // Detectar número de serie
    if (
      (palabras.some(p => p === 'serie' || p === 'serial' || p === 'ser')) &&
      (palabras.some(p => p === 'nro' || p === 'num' || p === 'numero' || p === 'no' || p === 'n'))
    ) {
      return { campo: 'nro_serie', confianza: 0.9 };
    }
    
    // Solo "serie" sin número
    if (palabras.some(p => p === 'serie' || p === 'serial')) {
      return { campo: 'nro_serie', confianza: 0.7 };
    }
  }
  
  return mejorCoincidencia;
}

export function importarExcel(archivo: File): Promise<ResultadoImportacion> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = (e) => {
      try {
        const data = e.target?.result;
        if (!data) {
          reject(new Error('No se pudo leer el archivo'));
          return;
        }

        let workbook: XLSX.WorkBook;
        
        try {
          workbook = XLSX.read(data, { 
            type: 'array',
            cellFormula: false,
            cellHTML: false,
            cellText: true
          });
        } catch (err) {
          reject(new Error('Error al procesar el archivo Excel. Verifique que el archivo no esté corrupto.'));
          return;
        }

        if (!workbook.SheetNames || workbook.SheetNames.length === 0) {
          reject(new Error('El archivo Excel no contiene hojas de trabajo'));
          return;
        }

        const primeraHoja = workbook.Sheets[workbook.SheetNames[0]];
        
        if (!primeraHoja) {
          reject(new Error('No se pudo leer la primera hoja del archivo'));
          return;
        }
        
        const jsonData = XLSX.utils.sheet_to_json(primeraHoja, { 
          header: 1,
          defval: '',
          blankrows: false
        }) as any[][];

        if (!jsonData || jsonData.length === 0) {
          resolve({
            datos: [],
            camposDetectados: [],
            camposFaltantes: [...CAMPOS_ESPERADOS],
            advertencias: ['El archivo no contiene datos'],
            totalFilas: 0
          });
          return;
        }

        if (jsonData.length < 2) {
          resolve({
            datos: [],
            camposDetectados: [],
            camposFaltantes: [...CAMPOS_ESPERADOS],
            advertencias: ['El archivo no contiene suficientes filas de datos'],
            totalFilas: 0
          });
          return;
        }

        // Obtener encabezados originales
        const encabezadosOriginales = jsonData[0].map(h => h?.toString()?.trim() || '');
        
        console.log('Encabezados originales del archivo:', encabezadosOriginales);

        // Detectar qué campos esperados están presentes
        const camposDetectados: CampoBien[] = [];
        const camposFaltantes: CampoBien[] = [];
        const advertencias: string[] = [];
        const mapeoIndices: Record<string, number> = {};
        const detecciones: Array<{ encabezado: string; campo: string; confianza: number; indice: number }> = [];

        // Analizar cada encabezado del archivo
        encabezadosOriginales.forEach((encabezado, indice) => {
          if (!encabezado) return;
          
          const deteccion = detectarTipoColumna(encabezado);
          
          if (deteccion.campo && deteccion.confianza >= 0.5) {
            detecciones.push({
              encabezado,
              campo: deteccion.campo,
              confianza: deteccion.confianza,
              indice
            });
          }
        });

        // Ordenar por confianza y seleccionar las mejores coincidencias
        detecciones.sort((a, b) => b.confianza - a.confianza);
        
        const camposYaDetectados = new Set<string>();
        
        detecciones.forEach(deteccion => {
          if (!camposYaDetectados.has(deteccion.campo)) {
            camposDetectados.push(deteccion.campo as CampoBien);
            mapeoIndices[deteccion.campo] = deteccion.indice;
            camposYaDetectados.add(deteccion.campo);
            
            console.log(`Campo detectado: "${deteccion.encabezado}" → ${deteccion.campo} (confianza: ${(deteccion.confianza * 100).toFixed(1)}%)`);
          }
        });

        // Determinar campos faltantes
        CAMPOS_ESPERADOS.forEach(campo => {
          if (!camposDetectados.includes(campo)) {
            camposFaltantes.push(campo);
          }
        });

        if (camposFaltantes.length > 0) {
          advertencias.push(`Campos no encontrados: ${camposFaltantes.map(c => 
            c.replace(/_/g, ' ').toUpperCase()
          ).join(', ')}`);
        }

        if (camposDetectados.length === 0) {
          reject(new Error(
            'No se detectaron campos válidos en el archivo. ' +
            'Encabezados encontrados: ' + encabezadosOriginales.join(', ') + '. ' +
            'Verifique que los encabezados coincidan con los esperados: ' +
            'codigo_patrimonial, responsable, usuario, descripcion, ubicac_fisica, marca, modelo, nro_serie, estado'
          ));
          return;
        }

        console.log('Campos detectados:', camposDetectados);
        console.log('Mapeo de índices:', mapeoIndices);

        // Procesar filas de datos
        const bienes: BienPatrimonial[] = [];
        
        for (let i = 1; i < jsonData.length; i++) {
          const fila = jsonData[i];
          
          if (!fila || !Array.isArray(fila) || fila.length === 0) continue;

          // Verificar que al menos un campo detectado tenga valor
          const tieneDatos = camposDetectados.some(campo => {
            const index = mapeoIndices[campo];
            if (index === undefined || index >= fila.length) return false;
            const valor = fila[index];
            return valor !== undefined && valor !== null && valor.toString().trim() !== '';
          });

          if (!tieneDatos) continue;

          const bien: BienPatrimonial = {
            id: `bien_${Date.now()}_${i}_${Math.random().toString(36).substr(2, 9)}`,
            codigo_patrimonial: '',
            responsable: '',
            usuario: '',
            descripcion: '',
            ubicac_fisica: '',
            marca: '',
            modelo: '',
            nro_serie: '',
            estado: ''
          };

          camposDetectados.forEach(campo => {
            const index = mapeoIndices[campo];
            if (index !== undefined && index < fila.length) {
              const valor = fila[index];
              (bien as any)[campo] = valor !== undefined && valor !== null ? valor.toString().trim() : '';
            }
          });

          bienes.push(bien);
        }

        console.log('Total de bienes procesados:', bienes.length);

        resolve({
          datos: bienes,
          camposDetectados,
          camposFaltantes,
          advertencias,
          totalFilas: bienes.length
        });

      } catch (error) {
        console.error('Error en importarExcel:', error);
        reject(error instanceof Error ? error : new Error('Error desconocido al procesar el archivo'));
      }
    };

    reader.onerror = () => {
      reject(new Error('Error al leer el archivo'));
    };

    reader.onabort = () => {
      reject(new Error('Lectura del archivo cancelada'));
    };

    reader.readAsArrayBuffer(archivo);
  });
}

export function exportarExcel(bienes: BienPatrimonial[], campos: CampoBien[]) {
  if (!bienes || bienes.length === 0) {
    throw new Error('No hay datos para exportar');
  }

  const datosExportar = bienes.map(bien => {
    const obj: Record<string, string> = {};
    campos.forEach(campo => {
      obj[campo] = (bien as any)[campo] || '';
    });
    return obj;
  });

  const workbook = XLSX.utils.book_new();
  const worksheet = XLSX.utils.json_to_sheet(datosExportar);

  const anchos = campos.map(campo => ({
    wch: Math.max(campo.length + 5, 15)
  }));
  worksheet['!cols'] = anchos;

  XLSX.utils.book_append_sheet(workbook, worksheet, 'Inventario SUNARP');

  const fecha = new Date().toISOString().split('T')[0];
  const nombreArchivo = `Inventario_SUNARP_2026_${fecha}.xlsx`;
  
  const wbout = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
  const blob = new Blob([wbout], { type: 'application/octet-stream' });
  
  saveAs(blob, nombreArchivo);
}
