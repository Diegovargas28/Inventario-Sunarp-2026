import { Toaster } from '@/components/ui/sonner';
import { Header } from '@/components/inventario/Header';
import { FileUploader } from '@/components/inventario/FileUploader';
import { FiltrosBusquedaComponent } from '@/components/inventario/FiltrosBusqueda';
import { TablaInventario } from '@/components/inventario/TablaInventario';
import { Estadisticas } from '@/components/inventario/Estadisticas';
import { Acciones } from '@/components/inventario/Acciones';
import { WaterMark } from '@/components/inventario/WaterMark';
import { useInventario } from '@/hooks/useInventario';
import { FileSpreadsheet, Info, AlertCircle, Loader2 } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

function App() {
  const {
    bienes,
    bienesFiltrados,
    cargando,
    error,
    filtros,
    camposDetectados,
    hayDatos,
    inicializado,
    importarArchivo,
    exportarArchivo,
    actualizarBien,
    eliminarBien,
    limpiarDatos,
    actualizarFiltro,
    limpiarFiltros
  } = useInventario();

  // Mostrar pantalla de carga inicial
  if (!inicializado) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-12 h-12 text-blue-900 animate-spin mx-auto mb-4" />
          <p className="text-gray-600">Cargando sistema de inventario...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100">
      <Toaster position="top-right" richColors />
      
      <Header />
      
      <main className="container mx-auto px-4 py-6 space-y-6">
        {/* Estadísticas */}
        {hayDatos && <Estadisticas bienes={bienes} />}

        {/* Sección de importación */}
        <section className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center gap-3 mb-5">
            <div className="bg-blue-100 rounded-lg p-2">
              <FileSpreadsheet className="w-6 h-6 text-blue-600" />
            </div>
            <div>
              <h2 className="text-xl font-semibold text-gray-800">Importar Datos</h2>
              <p className="text-sm text-gray-500">
                Cargue su archivo Excel con el inventario institucional
              </p>
            </div>
          </div>

          <Alert className="mb-5 bg-blue-50 border-blue-200">
            <Info className="h-4 w-4 text-blue-600" />
            <AlertTitle className="text-blue-800 text-sm font-medium">
              Formatos de encabezados soportados
            </AlertTitle>
            <AlertDescription className="text-blue-700 text-xs mt-1">
              codigo_patrimonial, responsable, usuario, descripcion, ubicac_fisica, 
              marca, modelo, nro_serie, estado
            </AlertDescription>
          </Alert>

          {/* Mostrar error general si existe */}
          {error && (
            <Alert className="mb-5 bg-red-50 border-red-200" variant="destructive">
              <AlertCircle className="h-4 w-4 text-red-600" />
              <AlertTitle className="text-red-800 text-sm font-medium">
                Error en la importación
              </AlertTitle>
              <AlertDescription className="text-red-700 text-xs mt-1">
                {error}
              </AlertDescription>
            </Alert>
          )}

          <FileUploader 
            onFileSelect={importarArchivo} 
            cargando={cargando} 
          />
        </section>

        {/* Acciones y gestión */}
        {hayDatos && (
          <Acciones
            onExportar={exportarArchivo}
            onLimpiar={limpiarDatos}
            hayDatos={hayDatos}
            totalRegistros={bienes.length}
          />
        )}

        {/* Filtros de búsqueda */}
        {hayDatos && (
          <FiltrosBusquedaComponent
            filtros={filtros}
            onFiltroChange={actualizarFiltro}
            onLimpiarFiltros={limpiarFiltros}
            totalResultados={bienesFiltrados.length}
          />
        )}

        {/* Tabla de inventario */}
        {hayDatos && (
          <section>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold text-gray-800">
                Lista de Bienes Patrimoniales
              </h2>
              {camposDetectados.length > 0 && (
                <p className="text-sm text-gray-500">
                  Campos detectados: {camposDetectados.length}/9
                </p>
              )}
            </div>
            
            <TablaInventario
              bienes={bienesFiltrados}
              camposDetectados={camposDetectados.length > 0 ? camposDetectados : undefined}
              onActualizar={actualizarBien}
              onEliminar={eliminarBien}
            />
          </section>
        )}

        {/* Estado vacío */}
        {!hayDatos && !cargando && (
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-12 text-center">
            <div className="bg-gray-100 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-5">
              <FileSpreadsheet className="w-10 h-10 text-gray-400" />
            </div>
            <h3 className="text-xl font-semibold text-gray-700 mb-2">
              Bienvenido al Sistema de Inventario SUNARP 2026
            </h3>
            <p className="text-gray-500 max-w-md mx-auto mb-6">
              Para comenzar, importe un archivo Excel con los datos del inventario institucional. 
              El sistema detectará automáticamente los campos disponibles.
            </p>
            <div className="flex items-center justify-center gap-2 text-sm text-gray-400">
              <Info className="w-4 h-4" />
              <span>Los datos se guardan automáticamente en su navegador</span>
            </div>
          </div>
        )}

        {/* Estado de carga */}
        {cargando && (
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-12 text-center">
            <Loader2 className="w-12 h-12 text-blue-900 animate-spin mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-700 mb-2">
              Procesando archivo...
            </h3>
            <p className="text-gray-500">
              Esto puede tomar unos momentos dependiendo del tamaño del archivo
            </p>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 mt-12">
        <div className="container mx-auto px-4 py-6">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="bg-blue-900 rounded-lg p-2">
                <FileSpreadsheet className="w-5 h-5 text-white" />
              </div>
              <div>
                <p className="text-sm font-semibold text-gray-800">
                  Sistema de Inventario SUNARP
                </p>
                <p className="text-xs text-gray-500">
                  Gestión de bienes patrimoniales institucionales
                </p>
              </div>
            </div>
            
            <div className="text-right">
              <p className="text-xs text-gray-400">
                © 2026 SUNARP - Superintendencia Nacional de los Registros Públicos
              </p>
              <p className="text-xs text-gray-400">
                Todos los derechos reservados
              </p>
            </div>
          </div>
        </div>
      </footer>

      {/* Marca de agua */}
      <WaterMark />
    </div>
  );
}

export default App;
